"""Session 5E-2d2 captures (brief section 7, "5E-2d1 LEFTOVERS"): one picture per reviewer note of Checkpoint 44, framed the same
way before (a tree given with --root, e.g. `git archive origin/main`) and after, plus the colony on LOW.
Shipped client (index.html), real renderer, scenario placements only (a jump, a camera framing, a UI tap). Software GL: looks
and counts only, never a phone frame rate.
usage: python3 dev/tests/conquest-leftovers-captures.py --mode world|town [--quality high|low] [--size 390x844] [--mouse]
       [--out DIR] [--tag before|after] [--only name,name] [--root DIR] [--sharp] [--dpr 2]
--mode world (the local economy; the pilot has no town): the see-through outline behind a thin thing and behind a building
 (note 1), an atmosphere pylon's dome and the settler block (2), the map as it opens (3, 10), the objective beam (4), the Command
 Base wall and towers (5: the art the style builds for a tier V base, stood on the base's own pad), steep banks (6), the colony
 (LOW), the docked heat panel beside the POWER pill (10).
--mode town (the real Worker on the fixture server, a fully built CC10 town): the town's miniature on the pad (8), the drive
 view as it opens (9), the town's ground in the build view (7).
Every run writes PNG pictures at the device's resolution and one JSON (draws, triangles, programs, the HUD boxes measured).
Sizes used by the session: 390x844, 320x568 (touch) and 1366x768 (--mouse: keyboard + mouse)."""
import argparse,asyncio,json,pathlib,shutil
from urllib.parse import urlparse
from playwright.async_api import async_playwright
HERE=pathlib.Path(__file__).resolve().parents[2]
SHARP='''for(const C of [self.WebGLRenderingContext,self.WebGL2RenderingContext]){if(!C)continue;const g=C.prototype.getParameter;C.prototype.getParameter=function(p){const v=g.call(this,p);return typeof v==='string'&&/swiftshader|llvmpipe|softpipe|software/i.test(v)?'Capture GPU':v;};}'''   # --sharp: the game holds a CPU rasterizer at .75x of the screen (js/graphics.js); a capture for LOOKS is drawn at the resolution a real device gets, by not telling the game the renderer is SwiftShader. Never used by a test that measures a budget.
# the steepest open bank on the terraformed side of the colony (found the same way in both trees: the terrain is the same)
STEEP='''(()=>{let b=[936,1197],bs=0;for(let x=900;x<=1320;x+=5)for(let z=1000;z<=1300;z+=5){if(W.solidAt(x,z)||W.waterAt(x,z))continue;const s=Math.hypot(W.groundAt(x+1.5,z)-W.groundAt(x-1.5,z),W.groundAt(x,z+1.5)-W.groundAt(x,z-1.5))/3;if(s>bs){bs=s;b=[x,z];}}return b;})()'''
BASE='[ConquestCombat.baseDefinition.x,ConquestCombat.baseDefinition.z]'
# name, subject ([x, z] in the page: F = the style's footprints, W = ConquestWorld), the side the tank stands on (degrees from
# +x toward +z, seen from the subject), stand-off (m), camera pitch, camera distance, kind:
#  '' = the camera looks over the tank at the subject (the world-kinds framing);
#  'across' = the camera stands on the far side of the subject and looks back at the tank, so the subject is in the way;
#  'thin:pole' / 'thin:lattice' / 'thin:slab' = the tank on open ground (where conquest-occluder.py stands it) with a thin thing
#   stood 6 m in front of it on the camera's line: a 0.4 m pole, a lattice leg (two 0.3 m uprights and their braces) or a
#   2.4 m slab that hides most of the hull (the outline: nothing behind the first two, the whole silhouette behind the third);
#  'census' = '' with the local raiders left alive, and the frame's triangles counted by what drew them (the colony, the frontier,
#   the Refuge, the ground, the scenery, the hostiles, the pilot's tank ...): where a frame's weight comes from, in either tree;
#  'fort' = '' with the tier V Command Base art stood on the pad; 'map' / 'hud' = a UI picture taken where the tank stands.
SHOTS=[
 ('note03-map-open',None,0,0,0,0,'map'),
 ('note10-hud',None,0,0,0,0,'hud'),
 ('note01-outline-pole','[1132,1240]',90,12,.42,30,'thin:pole'),
 ('note01-outline-lattice','[1132,1240]',90,12,.42,30,'thin:lattice'),
 ('note01-outline-slab','[1132,1240]',90,12,.42,30,'thin:slab'),
 ('note01-outline-pylon','[1004,1122]',90,13,.55,30,'across'),
 ('note01-outline-pylon-foot','[1004,1122]',90,7,.2,30,'across'),
 ('note01-outline-building','[1218,1096]',90,9,.2,34,'across'),
 ('note02-atmo-pylon','[1004,1122]',90,14,.18,22,''),
 ('note02-colony-block','[1194,1096]',90,14,.24,20,''),
 ('note04-beam-near',BASE,270,40,.1,24,''),
 ('note04-beam-far',BASE,270,150,.08,22,''),
 ('note05-base-fort',BASE,315,36,.45,28,'fort'),   # from the front corner (the monorail passes the gate side: straight on, its beam fills the frame)
 ('note05-base-wall',BASE,0,30,.28,24,'fort'),
 ('note05-base-tower','[ConquestCombat.baseDefinition.x+15,ConquestCombat.baseDefinition.z-13]',300,14,.25,16,'fort'),
 ('note06-bank-steepest',STEEP,90,16,.3,22,''),
 ('note06-bank-terminal','[F.terminal.x,F.terminal.z]',90,9,.8,24,''),
 ('note06-bank-wall','[1255,1166]',200,14,.5,26,''),
 ('note06-bank-crater','[922,1179]',315,18,.34,25,''),
 ('census-raid','[905,925]',90,0,.95,100,'census'),   # the scene conquest-session6c.py samples (its raid's own camera), with what each part of the world draws
 ('census-colony','[1062,1090]',135,24,.32,38,'census'),
 ('colony-core','[1062,1090]',135,24,.32,38,''),
 ('colony-homes','[1146,1108]',90,13,.3,17,''),
 ('colony-plaza','[1012,1096]',90,16,.5,28,''),
 ('colony-hall','[1014,1144]',90,15,.28,21,''),
 ('note03-map-colony',None,0,0,0,0,'map'),
]
PLACE='''([deg,stand,pitch,dist,across,keep])=>{const v=Conquest.view,W=ConquestWorld,F=v.style.footprints,S=(SUBJ),a=deg*Math.PI/180,dx=Math.cos(a),dz=Math.sin(a);
 const free=(x,z)=>{for(let k=0;k<8;k++)if(W.solidAt(x+Math.cos(k*.785)*5,z+Math.sin(k*.785)*5))return false;return !W.solidAt(x,z)&&!W.waterAt(x,z);};
 const rise=(x,z)=>{const fx=S[0]-x,fz=S[1]-z,l=Math.hypot(fx,fz)||1,g0=W.groundAt(x,z),h=Math.cos(pitch)*dist;let worst=0;for(let i=1;i<=16;i++){const t=i/16,g=W.groundAt(x-fx/l*h*t,z-fz/l*h*t);worst=Math.max(worst,(g-g0)/t-Math.sin(pitch)*dist);}return worst;};
 let x=0,z=0,best=1e9;for(const off of [0,25,-25,50,-50,80,-80,115,-115,150,-150,180]){const b=a+off*Math.PI/180,p=S[0]+Math.cos(b)*stand,q=S[1]+Math.sin(b)*stand;if(!free(p,q))continue;const sc=(across?0:Math.max(0,rise(p,q)))+Math.abs(off)*.004;if(sc<best){best=sc;x=p;z=q;}if(sc<.5)break;}
 if(best>1e8){x=S[0]+dx*stand;z=S[1]+dz*stand;search:for(let r=2;r<=22;r+=2)for(let k=0;k<16;k++){const p=x+Math.cos(k*.3927)*r,q=z+Math.sin(k*.3927)*r;if(free(p,q)){x=p;z=q;break search;}}}
 const fx=S[0]-x,fz=S[1]-z,yaw=across?Math.atan2(fx,fz):Math.atan2(-fx,-fz);v.jump(x,z);v.heading=Math.atan2(fx,fz)+(across?1.2:0);v.yaw=yaw;v.pitch=pitch;v.distance=dist;v.camSnap=true;
 const E=v.encounter;if(E){if(!keep)for(const e of E.enemies||[]){e.hp=0;if(E.cleared)E.cleared[e.key]=true;}E.playerHp=E.playerMax;}return {yaw,at:[x,z],subject:S};}'''
# one more render of the same frame with every draw's triangles booked to the part of the world that owns the mesh
CENSUS='''()=>{const v=Conquest.view,r=v.renderer,orig=r.renderBufferDirect,by={},foes=new Set(v.enemyMeshes?[...v.enemyMeshes.values()]:[]),pals=new Set([...(v.friendViews?.values()||[])].map(F=>F.g));
 const tag=o=>{for(let p=o;p;p=p.parent){if(p===v.vehicle)return 'pilot tank';if(foes.has(p)||p.userData&&p.userData.unit)return 'hostiles';if(pals.has(p))return 'allies';if(p===v.baseGroup)return 'command base';if(p.name&&p.name.indexOf('cq-')===0)return p.name.replace(/-[0-9].*$/,'').replace(/-(main|detail|core|smoke)$/,'');if(p===v.props)return 'props (refuge, viaduct, hives, cover)';}
  return o.isInstancedMesh?'scenery (instanced)':o.geometry&&o.geometry.userData&&o.geometry.userData.hfShared?'shared':'ground and scenery chunks';};
 if(typeof orig!=='function')return null;r.renderBufferDirect=function(c,s,g,m,o){const t0=r.info.render.triangles;orig.apply(this,arguments);const k=tag(o);by[k]=(by[k]||0)+r.info.render.triangles-t0;};
 try{r.render(v.scene,v.camera);}finally{r.renderBufferDirect=orig;}return {by,total:Object.values(by).reduce((a,b)=>a+b,0),hostilesAlive:(v.encounter?.enemies||[]).filter(e=>e.hp>0&&Math.hypot(e.x-v.p.x,e.z-v.p.z)<160).length};}'''
THIN='''what=>{const v=Conquest.view,T=v.T;for(const m of window.__thin||[]){m.parent&&m.parent.remove(m);m.geometry.dispose();}window.__thin=[];if(!what)return;
 const cam=v.camera.position,t=v.vehicle.position,d=new T.Vector3(cam.x-t.x,0,cam.z-t.z).normalize(),r=new T.Vector3(d.z,0,-d.x),mat=window.__thinMat||(window.__thinMat=new T.MeshLambertMaterial({color:0x8090a0}));
 const bar=(off,y,w,h,tilt)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,Math.min(w,.4)),mat);m.position.copy(t).addScaledVector(d,6).addScaledVector(r,off);m.position.y=t.y+y;m.quaternion.setFromAxisAngle(d,tilt||0).multiply(new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),Math.atan2(d.x,d.z)));m.position.sub(v.props.position);m.name='leftovers-thin';v.props.add(m);window.__thin.push(m);};
 if(what==='pole')bar(0,7,.4,18);
 if(what==='lattice'){bar(-1.1,7,.3,18);bar(1.1,7,.3,18);for(let k=0;k<5;k++){bar(0,.6+k*3.2,.16,3.6,k%2?.62:-.62);bar(0,-.9+k*3.2,2.2,.16,0);}}
 if(what==='slab')bar(.5,7,2.4,18);}'''
FRAMES='n=>new Promise(r=>{let k=0;const f=()=>++k<n?requestAnimationFrame(f):r();requestAnimationFrame(f);})'
INFO='(()=>{const v=Conquest.view,i=v.renderer.info;return {calls:i.render.calls,tris:i.render.triangles,programs:i.programs?.length};})()'
BOX='''s=>{const e=typeof s==='string'?document.querySelector(s):s;if(!e)return null;const r=e.getBoundingClientRect(),c=getComputedStyle(e);return {x:+r.x.toFixed(1),y:+r.y.toFixed(1),w:+r.width.toFixed(1),h:+r.height.toFixed(1),shown:c.display!=='none'&&c.visibility!=='hidden'&&r.width>0};}'''
# the map as it opens: the canvas and every button of its control row, against the screen (a button below the fold is one a pilot
# has to scroll to); read before anything scrolls
MAPBOX='''()=>{const B=('''+BOX+'''),d=document.querySelector('.cq-dialog.cq-map'),o={screen:[innerWidth,innerHeight],dialog:B(d),scroll:d?[d.scrollTop,d.scrollHeight,d.clientHeight]:null,canvas:B('.cq-map canvas'),buttons:{}};
 for(const b of document.querySelectorAll('.cq-map-controls button'))o.buttons[b.textContent.trim()]=B(b);return o;}'''
# the docked heat panel beside the POWER pill, with the pill as it reads plain, while a change shows ("POWER 92 -> 94") and
# with a pending value under it ("-> 60 at the Refuge"); gap = px between the pill's right edge and the panel's left edge
# when they share a row (negative: they overlap)
HUDBOX='''()=>{const B=('''+BOX+'''),chip=document.querySelector('.cq-rating-power-field'),heat=document.querySelector('.cq-world .cq-heat,.cq-heat'),o={screen:[innerWidth,innerHeight],cases:{}};
 const read=()=>{const a=B(chip),b=B(heat);return {pill:a,heat:b,text:chip?chip.textContent:null,rowShared:!!(a&&b&&a.y<b.y+b.h&&b.y<a.y+a.h),gap:a&&b?+(b.x-(a.x+a.w)).toFixed(1):null};};
 o.cases.plain=read();const R=window.ConquestRating;
 if(chip&&R&&R.update){const v=Number(chip.dataset.v)||68;try{R.update(chip,v+24,{});o.cases.delta=read();R.update(chip,v+24,{next:v+48,note:'at the Refuge'});o.cases.pending=read();}catch(e){o.error=String(e);}}
 o.top=[...document.querySelectorAll('.cq-top,.cq-navigation,.cq-combat-hud,.cq-coords,.cq-rating-power-field,.cq-heat,.cq-objective,.cq-world .cq-zoom,.cq-retreat,.cq-low-hull')].map(e=>({cls:e.className,box:B(e)})).filter(e=>e.box&&e.box.shown);return o;}'''
async def launch(p):return await p.chromium.launch(executable_path=shutil.which('chromium') or '/opt/pw-browsers/chromium',args=['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader'])
async def world(a,ROOT,out,w,h):
 shots=[s for s in SHOTS if not a.only or s[0] in a.only.split(',')];info={}
 async with async_playwright() as p:
  browser=await launch(p)
  ctx=await browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1 if a.mouse else a.dpr,has_touch=not a.mouse,is_mobile=not a.mouse,reduced_motion='reduce')
  page=await ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.add_init_script(SHARP) if a.sharp else None;await page.add_init_script('window.LUNAR_LOCAL_ECO=1;window.LUNAR_NO_CS=1;window.LUNAR_NO_PVP=1;window.LUNAR_NO_AUTOGFX=1;window.LUNAR_STYLE_QUALITY='+json.dumps(a.quality)+';try{localStorage.setItem("lunar-conquest-onboarding-v1","1")}catch(e){}')
  async def route(r):
   u=urlparse(r.request.url);f=ROOT/u.path.lstrip('/')
   if u.netloc=='lunar.test' and f.is_file():return await r.fulfill(path=str(f))
   await r.abort()
  await page.route('**/*',route)
  await page.goto('https://lunar.test/index.html');await page.wait_for_function('typeof Conquest!=="undefined"&&typeof closeAll==="function"')
  await page.evaluate('closeAll();save.welcomed=true;save.gfx='+json.dumps(a.quality)+';uiDirty();');await page.locator('[data-act="conquest"]').click();await page.get_by_role('button',name='ENTER CONQUEST',exact=True).click()
  await page.wait_for_function('typeof Conquest!=="undefined"&&!!Conquest.view',timeout=120000)
  if await page.locator('.cq-transmission').count():await page.locator('.cq-story-start').click()
  await page.wait_for_function('Conquest.view.pending===0',timeout=900000);await page.wait_for_timeout(1500)
  for name,subj,deg,stand,pitch,dist,kind in shots:
   path=str(out/f'{name}-{a.size}-{a.quality}-{a.tag}.png')
   if kind=='map':
    await page.get_by_role('button',name='OPEN MAP',exact=True).click();await page.wait_for_selector('.cq-map canvas');await page.wait_for_timeout(1200)
    info[name]=await page.evaluate(MAPBOX);await page.screenshot(path=path,timeout=180000)
    await page.locator('.cq-map canvas').screenshot(path=path.replace('.png','.canvas.png'),timeout=180000)   # the map alone, to read its labels
    await page.get_by_role('button',name='CLOSE MAP',exact=True).click();await page.wait_for_timeout(400);print(name,json.dumps(info[name]),flush=True);continue
   if kind=='hud':
    await page.wait_for_timeout(600);info[name]=await page.evaluate(HUDBOX);await page.screenshot(path=path,timeout=180000);print(name,json.dumps(info[name]),flush=True);continue
   placed=await page.evaluate(PLACE.replace('SUBJ',subj),[deg,stand,pitch,dist,kind=='across',kind=='census']);await page.wait_for_timeout(400)
   try:await page.wait_for_function('Conquest.view.pending===0',timeout=600000)
   except Exception:print('WARNING still streaming at the shot:',name,flush=True)
   if kind=='fort':   # the art the style builds for a tier V base without a town on its pad (the wall on three sides, the gate, both corner towers), in place of the build site's
    await page.evaluate('''()=>{const v=Conquest.view,g=v.baseGroup;if(!g||g.userData.capFort)return;for(const c of g.children)c.visible=false;const art=v.style.commandBase({tier:5,modules:{}},{paint:'#2c3a49'});g.add(art);g.userData.capFort=true;}''')
   await page.evaluate('([yaw,pitch,dist])=>{const v=Conquest.view;v.yaw=yaw;v.pitch=pitch;v.distance=dist;v.camSnap=true;if(v.style&&v.style.atmo)v.style.atmo(v.p,10);}',[placed['yaw'],pitch,dist])
   look=kind=='across' or kind.startswith('thin')
   if kind.startswith('thin'):await page.wait_for_timeout(a.settle);await page.evaluate(FRAMES,3);await page.evaluate(THIN,kind[5:])
   await page.wait_for_timeout(a.settle);await page.evaluate(FRAMES,44 if look else 3)   # the outline asks one question a frame (14 a round): three rounds
   await page.screenshot(path=path,timeout=180000)
   info[name]=dict(placed,**await page.evaluate(INFO))
   if kind.startswith('thin'):await page.evaluate(THIN,'')
   if kind=='census':
    if name=='census-raid':await page.evaluate('()=>{const v=Conquest.view;v.yaw=-.8;v.pitch=.95;v.distance=100;v.camera.fov=75;v.camera.updateProjectionMatrix();v.camSnap=true;}');await page.wait_for_timeout(a.settle);await page.evaluate(FRAMES,3);await page.screenshot(path=path,timeout=180000);info[name]=dict(placed,**await page.evaluate(INFO))
    info[name]['census']=await page.evaluate(CENSUS)
    if name=='census-raid':await page.evaluate('()=>{const v=Conquest.view;v.camera.fov=55;v.camera.updateProjectionMatrix();}')   # the exploration camera's own angle (js/conquest/view.js)
   if look:info[name]['outline']=await page.evaluate('''(()=>{const v=Conquest.view,o=v.outline;if(!o)return null;const s=o.sets&&o.sets.get(v.vehicle);return {twinsShown:(o.group.children||[]).filter(m=>m.visible&&m.userData.outlineTwin).length,whole:s?!!s.whole:null,hidden:s?s.nh:null};})()''')
   print(name,json.dumps(info[name]),flush=True)
  (out/f'world-{a.size}-{a.quality}-{a.tag}.json').write_text(json.dumps({'errors':errors,'shots':info},indent=1))
  assert not errors,errors
  await browser.close()
async def town(a,ROOT,out,w,h):
 only=a.only.split(',') if a.only else None;want=lambda n:not only or n in only;info={}
 server=await asyncio.create_subprocess_exec('node','dev/tests/conquest-server.mjs',cwd=ROOT,stdout=asyncio.subprocess.PIPE)
 ready=json.loads(await server.stdout.readline());base='http://127.0.0.1:'+str(ready['port'])
 try:
  async with async_playwright() as p:
   browser=await launch(p)
   ctx=await browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1 if a.mouse else a.dpr,has_touch=not a.mouse,is_mobile=not a.mouse,reduced_motion='reduce')
   page=await ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.add_init_script(SHARP) if a.sharp else None;await page.add_init_script('''window.LUNAR_NO_CS=1;window.LUNAR_NO_PVP=1;window.LUNAR_NO_AUTOGFX=1;window.LUNAR_STYLE_QUALITY='''+json.dumps(a.quality)+''';try{localStorage.setItem("lunar-conquest-onboarding-v1","1")}catch(e){};window.Telegram={WebApp:{initData:'''+json.dumps(ready['initData'])+''',initDataUnsafe:{user:{id:8301,first_name:'BrowserPilot'}},isVersionAtLeast:()=>false,ready(){},expand(){},onEvent(){},offEvent(){},BackButton:{show(){},hide(){},onClick(){}},HapticFeedback:{impactOccurred(){},notificationOccurred(){}}}};''')
   async def route(r):
    u=urlparse(r.request.url);f=ROOT/u.path.lstrip('/')
    if u.path.startswith('/api/conquest/') or u.path in ('/api/sync','/api/act'):
     body=json.loads(r.request.post_data or '{}')
     for attempt in range(2):
      try:resp=await page.request.post(base+u.path,data=body);return await r.fulfill(status=resp.status,body=await resp.body(),content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
      except Exception:
       if attempt:return await r.fulfill(status=503,body='{}',content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
       await asyncio.sleep(0.2)
    if u.path.startswith('/api/'):return await r.fulfill(body='{}',content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
    if u.netloc=='lunar.test' and f.is_file():return await r.fulfill(path=str(f))
    if u.netloc=='telegram.org':return await r.fulfill(body='',content_type='application/javascript')
    await r.abort()
   await page.route('**/*',route)
   fixture={'position':[1080,1160],'plotFull':'crater','baseFunds':True}
   await page.request.post(base+'/fixture',data=fixture)
   await page.goto('https://lunar.test/index.html');await page.wait_for_function('typeof Conquest!=="undefined"')
   await page.request.post(base+'/fixture',data=fixture)
   await page.evaluate('closeAll();save.welcomed=true;save.gfx='+json.dumps(a.quality)+';uiDirty();');await page.locator('[data-act="conquest"]').click();await page.get_by_role('button',name='ENTER CONQUEST',exact=True).click()
   if await page.locator('.cq-transmission').count():await page.locator('.cq-story-start').click()
   await page.wait_for_function('Conquest.view?.authority?.connected&&Conquest.view.pending===0',timeout=600000)
   png=lambda n:str(out/f'{n}-{a.size}-{a.quality}-{a.tag}.png')
   # note 8: the town's miniature on the pad, from where the pilot stands beside it (the game moves the tank off the model) and from
   # further off, the camera looking across the pad
   await page.wait_for_function('!!Conquest.view.diorama',timeout=600000);await page.wait_for_timeout(2500)
   for n,pitch,dist in (('note08-pad-chase',.42,26),('note08-pad-far',.5,44),('note08-pad-above',.9,40)):
    if not want(n):continue
    await page.evaluate('([pitch,dist])=>{const v=Conquest.view,D=ConquestCombat.baseDefinition,fx=D.x-v.p.x,fz=D.z+1.5-v.p.z;v.yaw=Math.atan2(-fx,-fz);v.pitch=pitch;v.distance=dist;v.camSnap=true;if(v.style&&v.style.atmo)v.style.atmo(v.p,10);}',[pitch,dist])
    await page.wait_for_timeout(a.settle);await page.evaluate(FRAMES,3);await page.screenshot(path=png(n),timeout=180000)
    info[n]=dict(await page.evaluate(INFO),pad=await page.evaluate('(()=>{const d=Conquest.view.diorama;let t=0,m=0;d.traverse(o=>{if(o.isMesh&&o.geometry){m++;const g=o.geometry,c=(g.index?g.index.count:g.attributes.position.count)/3;t+=c*(o.isInstancedMesh?o.count:1);}});return {meshes:m,tris:Math.round(t),counts:d.userData.counts};})()'));print(n,json.dumps(info[n]),flush=True)
   # note 9: the drive view exactly as it opens (the town opens in it); note 7: the town's ground in the build view, whole and close
   await page.locator('#cq-base-access').click();await page.wait_for_selector('.cq-plot-tabs',timeout=120000)
   await page.evaluate('ConquestPlotView.state.view==="drive"||ConquestPlotView.setView("drive")');await page.wait_for_function('ConquestPlotView.state.view==="drive"&&!ConquestPlotView.state.tour',timeout=240000);await page.wait_for_timeout(a.settle+2500)
   if want('note09-drive-open'):
    await page.screenshot(path=png('note09-drive-open'),timeout=180000);info['note09-drive-open']=await page.evaluate('(()=>{const X=ConquestPlotView.state,d=X.drive||{};return Object.assign({},X.info,{heading:d.h,chase:X.chase,pad:d.pad&&[d.pad.x,d.pad.z]});})()');print('note09-drive-open',json.dumps(info['note09-drive-open']),flush=True)
   if want('note07-ground-drive'):   # the ground beside the tank, the chase camera pulled back to its far stop
    await page.evaluate('ConquestPlotView.state.chase.dist=40');await page.wait_for_timeout(a.settle+1200);await page.screenshot(path=png('note07-ground-drive'),timeout=180000);info['note07-ground-drive']=await page.evaluate('ConquestPlotView.state.info')
   await page.evaluate('ConquestPlotView.setView("build")');await page.wait_for_function('ConquestPlotView.state.view==="build"',timeout=60000);await page.wait_for_timeout(a.settle+2500)
   if want('note07-ground-build'):await page.screenshot(path=png('note07-ground-build'),timeout=180000);info['note07-ground-build']=await page.evaluate('ConquestPlotView.state.info')
   for n,dist,k in (('note07-ground-close',60,1.0),('note07-ground-edge',90,.55)):   # the open ground outside the wall, south of the town (the pattern repeated where nothing stands on it)
    if not want(n):continue
    await page.evaluate('([dist,k])=>{const X=ConquestPlotView.state,P=ConquestPlot,p=Conquest.view.authority.state.plot;X.cam.dist=dist;X.cam.x=0;X.cam.z=(P.townH(p.cc)+5)*P.GRID.cell*k;}',[dist,k])
    await page.wait_for_timeout(a.settle+1500);await page.screenshot(path=png(n),timeout=180000);info[n]=await page.evaluate('ConquestPlotView.state.info')
   (out/f'town-{a.size}-{a.quality}-{a.tag}.json').write_text(json.dumps({'errors':errors,'shots':info},indent=1))
   assert not errors,errors
   await browser.close()
 finally:
  server.terminate();await server.wait()
async def main(a):
 ROOT=pathlib.Path(a.root).resolve() if a.root else HERE;out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True);w,h=[int(v) for v in a.size.split('x')]
 await (town if a.mode=='town' else world)(a,ROOT,out,w,h)
ap=argparse.ArgumentParser();ap.add_argument('--mode',default='world');ap.add_argument('--quality',default='high');ap.add_argument('--size',default='390x844');ap.add_argument('--mouse',action='store_true');ap.add_argument('--out',default=str(HERE/'docs/conquest/session5e2d2/leftovers'));ap.add_argument('--tag',default='after');ap.add_argument('--only',default='');ap.add_argument('--dpr',type=float,default=2);ap.add_argument('--settle',type=int,default=900);ap.add_argument('--root',default='');ap.add_argument('--sharp',action='store_true')
asyncio.run(main(ap.parse_args()))
